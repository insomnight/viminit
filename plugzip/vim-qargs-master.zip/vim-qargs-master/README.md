Note: The functionality provided by this project has been made largely obsolete in recent versions of vim. :cdo and :cfdo allow you operate directly on the quickfix list instead of first populating the argument list from the quickfix list.

A Vim plugin that adds a :Qargs utility command, for populating the argument
list from the files in the quickfix list.

For an example of usage, refer to the question [Search & replace using quickfix list in Vim](http://stackoverflow.com/a/5686810/128850).
